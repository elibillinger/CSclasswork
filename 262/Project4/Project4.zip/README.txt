1. Eli Billinger
2. A challenge that I faced was expanding the tree with new nodes. During my first attempt I over complicated the code and that caused the program to crash.
After using the debugger I found this code was making it crash and when I commented it out the program worked like it was supposed to.
3. I liked how this had us implement binary trees it to a realistic project that was a easy to understand game.
4. I spent about 3 hours on this assignment.
