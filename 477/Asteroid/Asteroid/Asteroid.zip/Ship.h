//
//  Ship.h
//  Asteroid
//
//  Created by Eli Billinger on 4/15/22.
//

#ifndef Ship_h
#define Ship_h
#include "Actor.h"
class Ship : public Actor
{
public:
    Ship(class Game* game);
};

#endif /* Ship_h */
