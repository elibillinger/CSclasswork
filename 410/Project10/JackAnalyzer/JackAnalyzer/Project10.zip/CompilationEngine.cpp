//
//  CompilationEngine.cpp
//  JackAnalyzer
//
//  Created by Eli Billinger on 5/3/22.
//

#include <stdio.h>
#include "CompilationEngine.h"


CompilationEngine::CompilationEngine(std::vector<std::string> tokens,std::vector<std::string> tokensXML, std::string output){
    tokenList = tokens;
    tokensListXML = tokensXML;
    
    output = "My"+output+ ".xml";
    outputStream.open(output);
    outfile = output;
}


void CompilationEngine::compile(){
    if(tokenList[0] == "class"){
        compileClass();
    }
}

void CompilationEngine::compileClass(){
    //add class overall output
    paresedList.push_back("<class>");
    //add class
    paresedList.push_back(tokensListXML[position]);
    position++;
    //add classname
    paresedList.push_back(tokensListXML[position]);
    position++;
    //add {
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    compileClassVarDec();
    compileSubroutine();
    
    //add }
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("</class>");
}

void CompilationEngine::compileClassVarDec(){
    
    if(tokenList[position] == "}"){
        return;
    }
    
    if(tokenList[position] == "static" || tokenList[position] == "field"){
        paresedList.push_back("<classVarDec>");
        paresedList.push_back(tokensListXML[position]);
        position++;
        
    } else {
        return;
    }
    
    compileType();
    
    while(true){
        //add varName
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        if(tokenList[position] == ","){
            //add ,
            paresedList.push_back(tokensListXML[position]);
            position++;
        } else {
            // add ;
            paresedList.push_back(tokensListXML[position]);
            position++;
            break;
        }
    }
    
    paresedList.push_back("</classVarDec>");
    
    compileClassVarDec();
}

void CompilationEngine::compileSubroutine(){
    
    if(tokenList[position] == "}"){
        return;
    }
    
    
    paresedList.push_back("<subroutineDec>");
    
    // output keyword tag for constructor/function, or method
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    
    if(tokenList[position] == "void"){
        //add void
        paresedList.push_back(tokensListXML[position]);
        position++;
    } else {
    //parse the type
    compileType();
    }
    
    //output subroutineName
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //output (
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //parse List
    compileParameterList();
    
    //output )
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //parse subroutine body
    compileSubroutineBody();
    
    paresedList.push_back("</subroutineDec>");
    
    compileSubroutine();
}

void CompilationEngine::compileParameterList(){
    
    
    if(tokenList[position] == ")"){
        paresedList.push_back("<parameterList>");
        paresedList.push_back("</parameterList>");
        return;
    }
    paresedList.push_back("<parameterList>");
    
    while (true) {
        compileType();
        //add varName
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        if(tokenList[position] == ","){
            //add ,
            paresedList.push_back(tokensListXML[position]);
            position++;
        } else {
            break;
        }
    }
    
    paresedList.push_back("</parameterList>");
    
}

void CompilationEngine::compileSubroutineBody(){
    paresedList.push_back("<subroutineBody>");
    //output {
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    if(tokenList[position] == "var"){
        compileVarDec();
    }
   
    paresedList.push_back("<statements>");
    compileStatements();
    paresedList.push_back("</statements>");
    
    //output }
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("</subroutineBody>");
}

void CompilationEngine::compileVarDec(){
    
    
    if(tokenList[position] == "var"){
        paresedList.push_back("<varDec>");
        paresedList.push_back(tokensListXML[position]);
        position++;
    } else {
        return;
    }
    
    compileType();
    
    while(true){
        //add varName
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        if(tokenList[position] == ";"){
            //add ;
            paresedList.push_back(tokensListXML[position]);
            position++;
            break;
        }
        //add ,
        paresedList.push_back(tokensListXML[position]);
        position++;
    }
    
    paresedList.push_back("</varDec>");
    
    compileVarDec();
}

void CompilationEngine::compileStatements(){
    
    if(tokenList[position] == "let"){
        compileLet();
        compileStatements();
    } else if (tokenList[position] == "if") {
        compileIf();
        compileStatements();
    } else if(tokenList[position] == "while"){
        compileWhile();
        compileStatements();
    } else if(tokenList[position] == "do"){
        compileDo();
        compileStatements();
    } else if (tokenList[position] == "return"){
        compileReturn();
        compileStatements();
    } else if(tokenList[position] == "}"){
        return;
    }

    
    
}

void CompilationEngine::compileLet(){
    paresedList.push_back("<letStatement>");
    
    // add let
    paresedList.push_back(tokensListXML[position]);
    position++;
    // add varName
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    if(tokenList[position] == "["){
        // add [
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        compileExpression();
        
        //add ]
        paresedList.push_back(tokensListXML[position]);
        position++;
    }
    

    //add =
    paresedList.push_back(tokensListXML[position]);
    position++;
        
    compileExpression();
    
    //add ;
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("</letStatement>");
}

void CompilationEngine::compileIf(){
    paresedList.push_back("<ifStatement>");
    
    // add if
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //add (
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    compileExpression();
    
    //add )
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //add {
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //statement
    paresedList.push_back("<statements>");
    compileStatements();
    paresedList.push_back("</statements>");
    
    //add }
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    if(tokenList[position] == "else"){
        //add else
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        //add {
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        //statement
        paresedList.push_back("<statements>");
        compileStatements();
        paresedList.push_back("</statements>");
        
        //add }
        paresedList.push_back(tokensListXML[position]);
        position++;
    }

    paresedList.push_back("</ifStatement>");
}

void CompilationEngine::compileWhile(){
    paresedList.push_back("<whileStatement>");
    
    //add while
    paresedList.push_back(tokensListXML[position]);
    position++;
    //add (
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    compileExpression();
    
    //add )
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    //add {
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("<statements>");
    compileStatements();
    paresedList.push_back("</statements>");
    
    //add }
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("</whileStatement>");
}

void CompilationEngine::compileDo(){
    paresedList.push_back("<doStatement>");
    //add Do
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    compileSubroutineCall();
    
    // add ;
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    paresedList.push_back("</doStatement>");
}

void CompilationEngine::compileReturn(){
    paresedList.push_back("<returnStatement>");
    
    //add return
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    if(tokenList[position] == ";"){
        //add ;
        paresedList.push_back(tokensListXML[position]);
        position++;
    } else {
        compileExpression();
        //add ;
        paresedList.push_back(tokensListXML[position]);
        position++;
    }
    
    
    
    paresedList.push_back("</returnStatement>");
}

void CompilationEngine::compileExpression(){
    paresedList.push_back("<expression>");
    
    compileTerm();
    
    
    
    while(true){
        //binary operator
        if(tokenList[position] == "<" || tokenList[position] == ">" || tokenList[position] == "&" || tokenList[position] == "+" || tokenList[position] == "-" || tokenList[position] == "*" || tokenList[position] == "=" || tokenList[position] == "/" || tokenList[position] == "|"){
            if(tokenList[position] == "<"){
                tokenList[position] = "&lt;";
            } else if(tokenList[position] == ">"){
                tokenList[position] = "&gt;";
            } else if(tokenList[position] == "&"){
                tokenList[position] = "&amp;";
            }
            
            //add the operator
            paresedList.push_back(tokensListXML[position]);
            position++;
            
            compileTerm();
        } else {
            break;
        }
    }
    
    
    
    paresedList.push_back("</expression>");
}

void CompilationEngine::compileTerm(){
    paresedList.push_back("<term>");
    std::string tokenType;
    
    size_t find = tokensListXML[position].find_first_of(WHITESPACE);
    if(find != std::string::npos){
       tokenType  = tokensListXML[position].substr(0,find);
    }
    
    
    // check if varName | varName[expression] | subroutineCall
    if(tokenType == "<identifier>"){
        int temp_postion = position;
        position++;
        if(tokenList[position] == "["){
            position = temp_postion;
            //add varName
            paresedList.push_back(tokensListXML[position]);
            position++;
            //add [
            paresedList.push_back(tokensListXML[position]);
            position++;
            
            compileExpression();
            //add ]
            paresedList.push_back(tokensListXML[position]);
            position++;
        } else if (tokenList[position] == "(" || tokenList[position] == "."){
            position = temp_postion;
            compileSubroutineCall();
        } else {
            position = temp_postion;
            //add varName
            paresedList.push_back(tokensListXML[position]);
            position++;
        }
        
        
    } else {
        if(tokenList[position] == "("){
            //add (
            paresedList.push_back(tokensListXML[position]);
            position++;
            
            compileExpression();
            
            //add )
            paresedList.push_back(tokensListXML[position]);
            position++;
        } else if(tokenList[position] == "-" || tokenList[position] == "~"){
            //add unaryop
            paresedList.push_back(tokensListXML[position]);
            position++;
            
            compileTerm();
        } else {
            // add int or string or keyword
            paresedList.push_back(tokensListXML[position]);
            position++;
            
        }
    }
    
    paresedList.push_back("</term>");
}

void CompilationEngine::compileExpressionList(){
    paresedList.push_back("<expressionList>");
    
    if(tokenList[position] != ")"){
    
    compileExpression();
    while(true){
        if(tokenList[position] == ","){
            //add ,
            paresedList.push_back(tokensListXML[position]);
            position++;
            compileExpression();
        } else {
            break;
        }
    }
    }
    
    paresedList.push_back("</expressionList>");
}

void CompilationEngine::compileType(){
    //add type
    paresedList.push_back(tokensListXML[position]);
    position++;
}


void CompilationEngine::compileSubroutineCall(){
    //add subroutine name
    paresedList.push_back(tokensListXML[position]);
    position++;
    
    if(tokenList[position] == "("){
        // add (
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        compileExpressionList();
        
        //add )
        paresedList.push_back(tokensListXML[position]);
        position++;
        
    } else if( tokenList[position] == "."){
        // add .
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        //add subroutine name
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        //add "("
        paresedList.push_back(tokensListXML[position]);
        position++;
        
        compileExpressionList();
        
        // add ")"
        paresedList.push_back(tokensListXML[position]);
        position++;
    }
    
    
    
}

void CompilationEngine::printXMLFile(){
    for(auto xmlOutputs: paresedList){
        outputStream << xmlOutputs << std::endl;
    }
}

void CompilationEngine::closeOutputFile(){
    outputStream.close();
}
